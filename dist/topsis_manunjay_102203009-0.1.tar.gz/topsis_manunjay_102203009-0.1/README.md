# Topsis - Multi-Criteria Decision Analysis

## Overview

This Python package implements the Topsis method for multi-criteria decision analysis (MCDA). It allows you to evaluate and rank alternatives based on multiple criteria with specified weights and impacts.

## Installation

You can install this package via pip:

